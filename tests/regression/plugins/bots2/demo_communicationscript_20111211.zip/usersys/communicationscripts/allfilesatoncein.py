import os
import glob
import shutil

def connect(channeldict):
    #make connection, place all files in right directory (channeldict['path'])
    print('\n\nconnect',channeldict['idchannel'])
    #copies the edi files from an existing dir to the dir where bots picks them up....just testing
    for fromfilename in glob.glob('botssys/infile/demo_comscript/source/*'):
        tofilename = os.path.join(channeldict['path'],os.path.basename(fromfilename))
        print('sends:', tofilename)
        shutil.copyfile(fromfilename,tofilename)

def disconnect(channeldict):
    print('disconnect',channeldict['idchannel'])
    #example of calling external program in communication script
    import subprocess
    subprocess.call(['cmd','/c', 'dir'])
