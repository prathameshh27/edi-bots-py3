<html xmlns:py="http://purl.org/kid/ns#">
<head>
    <title>Orders by Bots Open Source Edi Software</title>
    <style type="text/css">
        body,html {
            font-family:	"lucida sans",sans-serif;
        	background-color:		#D1DDEE;
            padding:  5px;
            }
        table.lines {
            border-collapse: collapse; 
            border: 1px solid #B4C9D3;
            }
        table.lines td {
            border: 1px solid #B4C9D3;
            padding:  5px;
            }
        hr.pageend {
            page-break-after:   always;
            }
        table.lines>thead>td {
            font-weight: bold;
            }
        h1	{
            font-size:		3ex;
            font-weight:    bold;
            }	
    </style>
</head>

<body>
<div py:strip="True" py:for="message in data">
    <div py:replace="document(message)"/>
    <hr class="pageend"/>
</div>
</body>
</html>
