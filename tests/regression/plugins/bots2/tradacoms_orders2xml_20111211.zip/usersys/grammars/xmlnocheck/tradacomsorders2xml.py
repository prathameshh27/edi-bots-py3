from bots.botsconfig import *

syntax = { 
        'merge': False,
        'indented':True,               #False: xml output is one string (no cr/lf); True: xml output is indented/human readable
        }
